
*************************************************************************
* File-Name: 	ReadMe.txt
* Date:  	06/22/2021
* Author: 	Michaël Aklin
* Purpose:   	ReadMe file to replicate:
*			Aklin, Michaël. Do High Electricity Bills 
*			Undermine Public Support for Renewables? 
*			Evidence from the European Union. Energy Policy.
*************************************************************************

This is the ReadMe file for the replication package of:

	Aklin, Michaël. Do High Electricity Bills Undermine Public 
	Support for Renewables? Evidence from the European Union. Energy Policy.

The replication package contains the following files:
> ReadMe.txt		This file
> ElectricityData.dta	A Stata dataset
> AklinElecPrice.do	A Stata script that replicates all tables and figures

To replicate the findings:
1. Download this replication package.
2. Change the path to the working directory in AklinElecPrice.do.

Important notice: some of the results require the original Eurobarometer data at the micro level, which I am not free to share. To replicate these findings, you will need to get access to the following dataset: 

	ZA6788_v2-0-0.dta

This dataset is available here:
	https://dbk.gesis.org/dbksearch/SDESC2.asp?no=6788&db=D

