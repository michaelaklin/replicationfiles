

*	************************************************************************
* 	File-Name: 	ReadMe.txt
*	Date:  		10/27/2020
*	Author: 	Michaël Aklin
*	Purpose:   	ReadMe file for Aklin (2020).
*	************************************************************************

# Overview

This file serves as the ReadMe.txt for the replication package of:

	Aklin, Michaël. "The Off-Grid Catch-22: Effective Institutions 
	as a Prerequisite for the Global Deployment of Distributed Renewable 
	Power." Energy Research & Social Science.

The replication package contains the following files:

# Content

- ReadMe.txt: this file.
- ReplicationData.dta: a Stata dat file that contains the variables needed to replicate the main results, tables, and figures.
- Analysis.do: a Stata script to generate the main results, tables, and figures. 
- Appendix.pdf: a pdf file that contains the supplementary material referred to in the article. 

# Instructions

To replicate the results reported in the paper:

1. Open Analysis.do

2. Change the working directory to the folder containing this package.

3. Run the script.
